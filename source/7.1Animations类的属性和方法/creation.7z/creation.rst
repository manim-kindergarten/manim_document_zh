Creation
========

.. admonition:: 声明

   这一页是elteoremadebeethoven写的 `manim_3feb_docs <https://elteoremadebeethoven.github.io/manim_3feb_docs.github.io/html/tree/animations/creation.html>`_  我翻译+做笔记，把资料整合编辑成方便的文档格式，以方便查阅使用Manim。



Draw
----

Show Partial
***************
.. autoclass:: manimlib.animation.creation.ShowPartial
    :members:

Show Creation
***************
.. autoclass:: manimlib.animation.creation.ShowCreation
    :members:
.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/ShowCreationExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class ShowCreationExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[ShowCreation(mob) for mob in mobjects]
          )
  
          self.wait()

Uncreate
*********
.. autoclass:: manimlib.animation.creation.Uncreate
    :members:
.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/UncreateExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class UncreateExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.add(mobjects)
  
          self.wait(0.3)
  
          self.play(
              *[Uncreate(mob) for mob in mobjects]
          )
  
          self.wait()

Draw Border Then Fill
**********************
.. autoclass:: manimlib.animation.creation.DrawBorderThenFill
    :members:
.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/DrawBorderThenFillExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class DrawBorderThenFillExample(Scene):
      def construct(self):
          vmobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          vmobjects.scale(1.5)
          vmobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[DrawBorderThenFill(mob) for mob in vmobjects]
          )
  
          self.wait()

Write
*****************
.. autoclass:: manimlib.animation.creation.Write
    :members:
.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/WriteExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class WriteExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[Write(mob) for mob in mobjects]
          )
  
          self.wait()

Fade
----

Fade Out
*****************
.. raw::
    .. autoclass:: manimlib.animation.creation.FadeOut
        :members:

AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeOut',新版本也没了。


.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeOutExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeOutExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.add(mobjects)
          self.wait(0.3)
  
          self.play(
              *[FadeOut(mob) for mob in mobjects]
          )
  
          self.wait()

Fade In
*****************
    .. autoclass:: manimlib.animation.creation.FadeIn
        :members:

AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeIn'，也没了。

.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeInExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeInExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[FadeIn(mob) for mob in mobjects]
          )
  
          self.wait()

Fade In From
***************************
    .. autoclass:: manimlib.animation.creation.FadeInFrom
        :members:


AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeInFrom',没了。

.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeInFromExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeInFromExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          directions=[UP,LEFT,DOWN,RIGHT]
  
          for direction in directions:
              self.play(
                  *[FadeInFrom(mob,direction) for mob in mobjects]
              )
  
          self.wait()

Fade In From Down
*****************
    .. autoclass:: manimlib.animation.creation.FadeInFromDown
        :members:
AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeInFromDown'，也没了。

.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeInFromDownExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeInFromDownExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[FadeInFromDown(mob) for mob in mobjects]
          )
  
          self.wait()

Fade Out And Shift
**********************
    .. autoclass:: manimlib.animation.creation.FadeOutAndShift
        :members:
AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeOutAndShift'






.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeOutAndShiftExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeOutAndShiftExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          directions=[UP,LEFT,DOWN,RIGHT]
  
          self.add(mobjects)
          self.wait(0.3)
  
          for direction in directions:
              self.play(
                  *[FadeOutAndShift(mob,direction) for mob in mobjects]
              )
  
          self.wait()

Fade Out And Shift Down
****************************
    .. autoclass:: manimlib.animation.creation.FadeOutAndShiftDown
        :members:

AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeOutAndShiftDown'




.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeOutAndShiftDownExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeOutAndShiftDownExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[FadeOutAndShiftDown(mob) for mob in mobjects]
          )
  
          self.wait()

Fade In From Large
*********************
    .. autoclass:: manimlib.animation.creation.FadeInFromLarge
        :members:
AttributeError: module 'manimlib.animation.creation' has no attribute 'FadeInFromLarge'


. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/FadeInFromLargeExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class FadeInFromLargeExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          scale_factors=[0.3,0.8,1,1.3,1.8]
  
          for scale_factor in scale_factors:
              t_scale_factor = TextMobject(f"\\tt scale\\_factor = {scale_factor}")
              t_scale_factor.to_edge(UP)
  
              self.add(t_scale_factor)
  
              self.play(
                  *[FadeInFromLarge(mob,scale_factor) for mob in mobjects]
              )
  
              self.remove(t_scale_factor)
  
          self.wait(0.3)

VFade In
*****************
    .. autoclass:: manimlib.animation.creation.VFadeIn
        :members:
AttributeError: module 'manimlib.animation.creation' has no attribute 'VFadeIn'





VFade Out
*****************
    .. autoclass:: manimlib.animation.creation.VFadeOut
        :members:



Grow
----

Grow From Point
********************
    .. autoclass:: manimlib.animation.creation.GrowFromPoint
        :members:






.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/GrowFromPointExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class GrowFromPointExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          directions=[UP,LEFT,DOWN,RIGHT]
  
          for direction in directions:
              self.play(
                  *[GrowFromPoint(mob,mob.get_center()+direction*3) for mob in mobjects]
              )
  
          self.wait()

Grow From Center
*****************
    .. autoclass:: manimlib.animation.creation.GrowFromCenter
        :members:


.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/GrowFromCenterExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class GrowFromCenterExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[GrowFromCenter(mob) for mob in mobjects]
          )
  
          self.wait()

Grow From Edge
*****************
    .. autoclass:: manimlib.animation.creation.GrowFromEdge
        :members:


.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/GrowFromEdgeExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class GrowFromEdgeExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Circle(),
                  Circle(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          directions=[UP,LEFT,DOWN,RIGHT]
  
          for direction in directions:
              self.play(
                  *[GrowFromEdge(mob,direction) for mob in mobjects]
              )
  
          self.wait()

Grow Arrow
***************
    .. autoclass:: manimlib.animation.creation.GrowArrow
        :members:




.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/GrowArrowExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class GrowArrowExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Arrow(LEFT,RIGHT),
                  Vector(RIGHT*2)
              )
          mobjects.scale(3)
          mobjects.arrange_submobjects(DOWN,buff=2)
  
          self.play(
              *[GrowArrow(mob)for mob in mobjects]
          )
  
          self.wait()

Spin In From Nothing
***********************
    .. autoclass:: manimlib.animation.creation.SpinInFromNothing
        :members:






.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/SpinInFromNothingExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class SpinInFromNothingExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Square(),
                  RegularPolygon(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[SpinInFromNothing(mob) for mob in mobjects]
          )
  
          self.wait()

Shrink To Center
*****************
    .. autoclass:: manimlib.animation.creation.ShrinkToCenter
        :members:





.. raw:: html

    <video width="560" height="315" controls>
        <source src="../_static/manim_3fed/ShrinkToCenterExample.mp4" type="video/mp4">
    </video>
.. code-block:: python

  class ShrinkToCenterExample(Scene):
      def construct(self):
          mobjects = VGroup(
                  Square(),
                  RegularPolygon(fill_opacity=1),
                  TextMobject("Text").scale(2)
              )
          mobjects.scale(1.5)
          mobjects.arrange_submobjects(RIGHT,buff=2)
  
          self.play(
              *[ShrinkToCenter(mob) for mob in mobjects]
          )
  
          self.wait()







